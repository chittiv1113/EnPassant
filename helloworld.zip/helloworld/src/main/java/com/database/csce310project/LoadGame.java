package com.database.csce310project;

public class LoadGame
{
    String FenValue;
    String CapturePiece;

    public String getFenValue() {
        return FenValue;
    }

    public void setFenValue(String fenValue) {
        FenValue = fenValue;
    }

    public String getCapturePiece() {
        return CapturePiece;
    }

    public void setCapturePiece(String capturePiece) {
        CapturePiece = capturePiece;
    }
}
