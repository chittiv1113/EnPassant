package com.database.csce310project;

import static java.lang.System.out;
import java.sql.*;
import java.util.Arrays;
import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;

public class processMoveClass 
{
    public static void printSQLException(SQLException ex) 
    {
        // the printSQLException() function was from the sample code that can be found on this page (in JDBCTutorialUtilities.java):
        // https://docs.oracle.com/javase/tutorial/jdbc/basics/gettingstarted.html

        for (Throwable e : ex) 
        {
            if (e instanceof SQLException) 
            {
                if (true) 
                {
                    e.printStackTrace(System.err);
                    System.err.println("SQLState: " + ((SQLException)e).getSQLState());
                    System.err.println("Error Code: " + ((SQLException)e).getErrorCode());
                    System.err.println("Message: " + e.getMessage());
                    Throwable t = ex.getCause();

                    while (t != null) 
                    {
                        System.out.println("Cause: " + t);
                        t = t.getCause();
                    }   
                }
            }
        }
    }

    public static Connection getConnection(String port, String database, String username, String password) throws Exception
    {
        Connection connection = null;
        Class.forName("org.postgresql.Driver");

        connection = DriverManager.getConnection("jdbc:postgresql://localhost:" + port + "/" + database, username, password);
        if(connection != null)
        {
            System.out.println("Connection established");
        }
        else
        {
            System.out.println("Connection not established");
        }     

        return connection;
    }

    public static String reformatCapturedPiece(String capturedPiece)
    {
        capturedPiece = capturedPiece.trim();
        if (capturedPiece.length() == 0)
            return capturedPiece;

        char capturedPieceChar = capturedPiece.charAt(0);
        String color = "";

        if ((int)capturedPieceChar < 97)
        {
            color = "w";
        }
        else
        {
            color = "b";
        }
        
        return color + capturedPiece.toUpperCase();
    }

    public static int getNewMoveID(Connection connection) throws SQLException
    {
        Statement statement = connection.createStatement();

        // find the largest move_id value currently in the table
        // so that we can assign the appropriate move_id to the new tuple
        int moveID = -1;
        String query = "SELECT MAX(move_id) AS max_move_id FROM moves";
        ResultSet results = statement.executeQuery(query);

        if(results.next())
        {
            moveID = results.getInt("max_move_id") + 1;
        }
        else
        {
            moveID = 0;
        }

        return moveID;
    }

    public static int getGameID(Connection connection) throws SQLException
    {
        Statement statement = connection.createStatement();

        // get the gameID to associate with the move being processed
        // this will always be the last game added in the database
        // (i.e. the maximum value of gameID currently in the games table)
        int gameID = -1;
        String query = "SELECT MAX(game_id) AS max_game_id FROM game";
        ResultSet results = statement.executeQuery(query);

        if(results.next())
        {
            gameID = results.getInt("max_game_id");
        }
        else
        {
            out.println("ERROR: attempted to play a move with no game in the database");
        }

        return gameID;
    }

    public static String simplifyFenString(String fen)
    {
        fen = fen.replace("/", "");
        for(int i = 0; i < 9; i++)
        {
            fen = fen.replace(String.valueOf(i), "");
        }
        return fen;
    }

//-----------------------------------------------------------------

    public static String getCapturedPiece(String currentFen, String previousFen) throws SQLException
    {
        // remove '/' and numbers from the FENs so that only the piece letters remain
        previousFen = simplifyFenString(previousFen);
        currentFen = simplifyFenString(currentFen);

        // check if a piece was captured
        // a piece is only captured if the previous FEN has more piece characters than the current FEN

        // if a piece was not captured
        if(previousFen.length() <= currentFen.length()){ return ""; }

        // if a piece was captured
        else if(previousFen.length() == (currentFen.length() + 1))
        {
            // sort the two strings
            char previousFenCharArray[] = previousFen.toCharArray();
            Arrays.sort(previousFenCharArray);

            char currentFenCharArray[] = currentFen.toCharArray();
            Arrays.sort(currentFenCharArray);

            previousFen = String.valueOf(previousFenCharArray);
            currentFen = String.valueOf(currentFenCharArray);

            // compare currentFen to previousFen and store unique characters for each array
            // (this could definitely be rewritten to make more sense)
            ArrayList<String> previousFenOnlyArrayList = new ArrayList<String>();
            for(int i = 0; i < previousFen.length(); i++)
            {
                previousFenOnlyArrayList.add(previousFen.substring(i, i + 1));
            }

            String remainingCurrentFen = currentFen;
            String currentFenOnly = "";
            //int currentFenOnlyCount = 0;
            while(remainingCurrentFen.length() > 0)
            {
                String letter = remainingCurrentFen.substring(0, 1);

                int previousFenLetterIndex = previousFenOnlyArrayList.indexOf(letter);

                if(previousFenLetterIndex != -1)
                {
                    previousFenOnlyArrayList.remove(previousFenLetterIndex);
                }
                else
                {
                    currentFenOnly += letter;
                }

                remainingCurrentFen = remainingCurrentFen.substring(1);
            }

            String previousFenOnly = "";
            for(int i = 0; i < previousFenOnlyArrayList.size(); i++)
            {
                previousFenOnly += previousFenOnlyArrayList.get(i);
            }
            
            // eliminate differences between previousFen and currentFen caused by promotions
            // (this is O(n^2) but n is never greater than 3)
            String combinedUnique = previousFenOnly + currentFenOnly;

            for(int i = 0; i < combinedUnique.length(); i++)
            {
                for(int j = i + 1; j < combinedUnique.length(); j++)
                {
                    char charAtI = combinedUnique.charAt(i);
                    char charAtJ = combinedUnique.charAt(j);

                    // if combinedUnique characters at index i and j are both uppercase (i.e. white)
                    if(((int)charAtI < 97 && (int)charAtJ < 97)

                    // if combinedUnique characters at index i and j are both lowercase (i.e. black)
                    || ((int)charAtI >= 97 && (int)charAtJ >= 97))
                    {
                        combinedUnique = combinedUnique.replace(String.valueOf(charAtI), "");
                        combinedUnique = combinedUnique.replace(String.valueOf(charAtJ), "");
                    }
                }
            }

            // after eliminating differences from promotions, the only remaining character in combinedUnique
            // will be the captured piece
            return combinedUnique;
        }
        else
        {
            out.println("ERROR: invalid length of previousFen or currentFen");
            return "";
        }

    }

    public static void insertToMovesTable(Connection connection, int moveID, int gameID, String fen, String capturedPiece) throws SQLException
    {
        Statement statement = connection.createStatement();

        // insert new tuple into moves table
        String query = "INSERT INTO moves(move_id, game_id, fen_string, capture_piece) VALUES (" + 
            String.valueOf(moveID) + ", " +
            String.valueOf(gameID) + ", \'" + 
            fen + "\', \'" + 
            capturedPiece + "\')";
        statement.executeUpdate(query);
    }

    // also returns material advantage
    public static String insertToMaterialTable(Connection connection, int moveID, String fen) throws SQLException
    {
        Statement statement = connection.createStatement();

        // find the largest mat_id value currently in the table
        // so that we can assign the appropriate mat_id to the new tuple
        int matID = -1;
        String query = "SELECT MAX(mat_ID) AS max_mat_id FROM material";
        ResultSet results = statement.executeQuery(query);

        if(results.next())
        {
            matID = results.getInt("max_mat_id") + 1;
        }
        else
        {
            matID = 0;
        }

        // find the material advantage given a FEN string
        fen = simplifyFenString(fen);
        int materialAdvantage = 0;
        for(int i = 0; i < fen.length(); i++)
        {
            switch(fen.substring(i, i + 1))
            {
                case "P":
                    materialAdvantage += 1;
                    break;
                case "N":
                    materialAdvantage += 3;
                    break;
                case "B":
                    materialAdvantage += 3;
                    break;
                case "R":
                    materialAdvantage += 5;
                    break;
                case "Q":
                    materialAdvantage += 9;
                    break;
                case "K":
                    materialAdvantage += 0;
                    break;

                case "p":
                    materialAdvantage -= 1;
                    break;               
                case "n":
                    materialAdvantage -= 3;
                    break;
                case "b":
                    materialAdvantage -= 3;
                    break;
                case "r":
                    materialAdvantage -= 5;
                    break;
                case "q":
                    materialAdvantage -= 9;
                    break;
                case "k":
                    materialAdvantage -= 0;
                    break;

                default:
                    out.println("ERROR: invalid piece in FEN string");
                    break;
            }
        }

        // insert new tuple into material table
        query = "INSERT INTO material(mat_id, move_id, mvalue) VALUES (" + 
            String.valueOf(matID) + ", " +
            String.valueOf(moveID) + ", " + 
            String.valueOf(materialAdvantage) + ")";
        statement.executeUpdate(query);

        String materialAdvantageString = String.valueOf(materialAdvantage);
        // if white is up X material, then their material advantage should read +X
        // (black's material advantage already reads -X)
        if(materialAdvantageString.length() == 1)
        {
            materialAdvantageString = "+" + materialAdvantageString;
        }

        return materialAdvantageString;
    }
}
